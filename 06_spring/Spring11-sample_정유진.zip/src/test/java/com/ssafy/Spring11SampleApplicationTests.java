package com.ssafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring11SampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
